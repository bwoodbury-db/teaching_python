def divide_by_two(number):
    print(int(number) / 2)


number = input("Type your number here: ")
divide_by_two(number=number)
