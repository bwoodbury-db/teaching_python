# Python is an interpreted language!
print("Hello World!")


def hiya_pal():
    var = "var"
    print("Hiya pal!")


print("buenos dias")
hiya_pal()
