# This file shows a while loop
import random

i = 0
while i < 10:
    randint = random.randint(0, 100)
    print(randint)
    i = i + 1
